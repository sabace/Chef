        module ChefCompat
          CHEF_UPSTREAM_VERSION="12.14.89"
        end
