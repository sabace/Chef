name              'rsyslog_test'
maintainer        'Chef Software, Inc.'
maintainer_email  'cookbooks@chef.io'
license           'Apache 2.0'
description       'Tests rsyslog cookbook'
version           '1.0'

depends 'rsyslog'
